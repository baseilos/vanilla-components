var d = function() {
  return d = Object.assign || function(r) {
    for (var i, e = 1, a = arguments.length; e < a; e++) {
      i = arguments[e];
      for (var o in i)
        Object.prototype.hasOwnProperty.call(i, o) && (r[o] = i[o]);
    }
    return r;
  }, d.apply(this, arguments);
};
var l = "en-US", t = function(n, r) {
  return r === void 0 && (r = {}), {
    __embeddableType: "built-in",
    toString: function() {
      return n;
    },
    typeConfig: d({ label: n, optionLabel: function() {
      return n;
    } }, r)
  };
}, u = function(n, r) {
  if (globalThis.__EMBEDDABLE__ = globalThis.__EMBEDDABLE__ || {}, globalThis.__EMBEDDABLE__.types = globalThis.__EMBEDDABLE__.types || {}, A.includes(n))
    throw new Error("Type ".concat(n, " is part of the nativeTpes and cannot be defined"), { cause: "sdk" });
  return globalThis.__EMBEDDABLE__.types[n] = d({ name: n }, r), {
    __embeddableType: "custom",
    toString: function() {
      return n;
    },
    typeConfig: r
  };
}, f = "string", D = "number", g = "boolean", T = "time", b = "timeRange", p = "granularity", v = "dataset", L = "measure", m = "dimension", B = "dimensionOrMeasure", A = [
  f,
  D,
  g,
  T,
  b,
  p,
  v,
  L,
  m,
  B
], s = function(n, r) {
  if (globalThis.__EMBEDDABLE__ = globalThis.__EMBEDDABLE__ || {}, typeof n == "string")
    globalThis.__EMBEDDABLE__.nativeTypes = globalThis.__EMBEDDABLE__.nativeTypes || {}, globalThis.__EMBEDDABLE__.nativeTypes[n] = globalThis.__EMBEDDABLE__.nativeTypes[n] || {}, globalThis.__EMBEDDABLE__.nativeTypes[n].options = globalThis.__EMBEDDABLE__.nativeTypes[n].options || [], globalThis.__EMBEDDABLE__.nativeTypes[n].options.push(r);
  else {
    var i = n.toString();
    if (!globalThis.__EMBEDDABLE__.types[i])
      return;
    globalThis.__EMBEDDABLE__.types[i].options = globalThis.__EMBEDDABLE__.types[i].options || [], globalThis.__EMBEDDABLE__.types[i].options.push(r);
  }
};
t("string", {
  transform: function(n) {
    return n;
  },
  optionLabel: function(n) {
    return Array.isArray(n) ? "[".concat(n.map(function(r) {
      return '"'.concat(r, '"');
    }).join(","), "]") : '"'.concat(n, '"');
  }
});
t("number", {
  transform: function(n) {
    return Array.isArray(n) ? n : n && Number(n);
  },
  optionLabel: function(n) {
    var r;
    return Array.isArray(n) ? "[".concat(n.join(","), "]") : (r = n == null ? void 0 : n.toLocaleString(l)) !== null && r !== void 0 ? r : "";
  }
});
t("boolean", {
  transform: function(n) {
    return n === "true" || n === !0;
  },
  optionLabel: function(n) {
    return n ? "true" : "false";
  }
});
t("time", {
  transform: function(n) {
    var r = n != null && n.date ? new Date(n.date) : void 0, i = r && r.toString() !== "Invalid Date";
    return {
      date: i ? r : void 0,
      relativeTimeString: n == null ? void 0 : n.relativeTimeString
    };
  },
  optionLabel: function(n) {
    var r, i;
    return n ? n != null && n.date ? (i = (r = n.date) === null || r === void 0 ? void 0 : r.toLocaleDateString(l)) !== null && i !== void 0 ? i : n.date.toLocaleString() : n.relativeTimeString : "";
  }
});
t("timeRange", {
  transform: function(n) {
    if (n) {
      var r = [n == null ? void 0 : n.from, n == null ? void 0 : n.to], i = r[0], e = r[1], a = new Date(i), o = new Date(e);
      return {
        from: a.toString() !== "Invalid Date" ? a : void 0,
        to: o.toString() !== "Invalid Date" ? o : void 0,
        relativeTimeString: n == null ? void 0 : n.relativeTimeString
      };
    }
  },
  optionLabel: function(n) {
    var r, i, e, a, o, E;
    return n ? n != null && n.from && (n != null && n.to) ? "".concat((i = (r = n.from) === null || r === void 0 ? void 0 : r.toLocaleDateString(l)) !== null && i !== void 0 ? i : (e = n.from) === null || e === void 0 ? void 0 : e.toLocaleString(), ",").concat((o = (a = n.to) === null || a === void 0 ? void 0 : a.toLocaleDateString(l)) !== null && o !== void 0 ? o : (E = n.to) === null || E === void 0 ? void 0 : E.toLocaleString()) : n == null ? void 0 : n.relativeTimeString : "";
  }
});
t("granularity", {
  transform: function(n) {
    return n;
  },
  optionLabel: function(n) {
    return n;
  }
});
t("dataset");
t("measure");
t("dimension");
t("dimensionOrMeasure");
const c = u("sortDirection", {
  label: "Sort Direction",
  optionLabel: (n) => n.value
});
s(c, { value: "Ascending" });
s(c, { value: "Descending" });
const _ = u("timeComparison", {
  label: "Time Comparison",
  optionLabel: (n) => n
});
s(_, "No comparison");
s(_, "Previous period");
s(_, "Previous month");
s(_, "Previous quarter");
s(_, "Previous year");
